package com.example.apipoc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApipocApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApipocApplication.class, args);
	}

}
